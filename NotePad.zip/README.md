# iOS-Style Web Notes App

A web-based notes application that mimics the clean and intuitive design of the iOS Notes app.

## Features
- Clean, iOS-like interface
- Create, edit, and delete notes
- Notes list sidebar
- Responsive design
- Local storage for data persistence

## Technologies Used
- HTML5
- CSS3
- JavaScript
- Font Awesome for icons

## Getting Started
1. Open `index.html` in your web browser
2. Start creating and managing your notes!
