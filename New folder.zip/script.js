/**
 * @fileoverview iOS Notes Web App - A modern note-taking application
 * @version 1.0.0
 * @author Your Name
 * @license MIT
 */

/**
 * Represents a single note in the application
 * @class
 */
class Note {
    /**
     * Creates a new Note instance
     * @param {string} title - The title of the note
     * @param {string} content - The content of the note
     * @param {number} timestamp - Creation timestamp
     */
    constructor(title = '', content = '', timestamp = new Date().getTime()) {
        this.id = timestamp;
        this.title = title;
        this.content = content;
        this.lastModified = timestamp;
    }
}

/**
 * Main application class that handles all note operations
 * @class
 */
class NotesApp {
    constructor() {
        this.initializeElements();
        this.attachEventListeners();
        this.currentNote = null;
        this.notes = [];
        this.loadNotes();
    }

    initializeElements() {
        // Get DOM elements
        this.sidebar = document.querySelector('.sidebar');
        this.notesList = document.getElementById('notesList');
        this.noteContent = document.querySelector('.note-content');
        this.sidebarToggle = document.getElementById('sidebarToggle');
        
        // Format buttons
        this.boldBtn = document.getElementById('boldBtn');
        this.italicBtn = document.getElementById('italicBtn');
        this.underlineBtn = document.getElementById('underlineBtn');
        this.strikeBtn = document.getElementById('strikeBtn');
        this.headingBtn = document.getElementById('headingBtn');
        this.quoteBtn = document.getElementById('quoteBtn');
        this.codeBtn = document.getElementById('codeBtn');
        this.listBtn = document.getElementById('listBtn');
        
        // File operations
        this.saveNoteBtn = document.getElementById('saveNoteBtn');
        this.deleteNoteBtn = document.getElementById('deleteNoteBtn');
        this.uploadBtn = document.getElementById('uploadBtn');
        this.uploadInput = document.getElementById('uploadInput');
    }

    attachEventListeners() {
        // Sidebar toggle
        this.sidebarToggle.addEventListener('click', () => {
            this.sidebar.classList.toggle('collapsed');
        });

        // Text formatting
        this.boldBtn.addEventListener('click', () => this.formatText('bold'));
        this.italicBtn.addEventListener('click', () => this.formatText('italic'));
        this.underlineBtn.addEventListener('click', () => this.formatText('underline'));
        this.strikeBtn.addEventListener('click', () => this.formatText('strikeThrough'));
        this.headingBtn.addEventListener('click', () => this.insertHeading());
        this.quoteBtn.addEventListener('click', () => this.insertQuote());
        this.codeBtn.addEventListener('click', () => this.insertCode());
        this.listBtn.addEventListener('click', () => this.formatText('insertUnorderedList'));

        // Note operations
        this.saveNoteBtn.addEventListener('click', () => this.saveCurrentNote());
        this.deleteNoteBtn.addEventListener('click', () => this.deleteCurrentNote());
        
        // File upload
        this.uploadBtn.addEventListener('click', () => this.uploadInput.click());
        this.uploadInput.addEventListener('change', (e) => this.handleFileUpload(e));

        // Note content changes
        this.noteContent.addEventListener('input', () => {
            if (this.currentNote) {
                this.currentNote.content = this.noteContent.innerHTML;
                this.saveNotes();
            }
        });
    }

    formatText(command) {
        document.execCommand(command, false, null);
        this.noteContent.focus();
    }

    insertHeading() {
        document.execCommand('formatBlock', false, '<h2>');
        this.noteContent.focus();
    }

    insertQuote() {
        document.execCommand('formatBlock', false, '<blockquote>');
        this.noteContent.focus();
    }

    insertCode() {
        document.execCommand('formatBlock', false, '<pre>');
        this.noteContent.focus();
    }

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const content = e.target.result;
            this.createNewNote(file.name, content);
        };
        reader.readAsText(file);
        this.uploadInput.value = ''; // Reset input
    }

    createNewNote(title = 'New Note', content = '') {
        const note = {
            id: Date.now(),
            title: title,
            content: content,
            date: new Date().toLocaleString()
        };

        this.notes.unshift(note);
        this.saveNotes();
        this.renderNotesList();
        this.selectNote(note);
    }

    selectNote(note) {
        this.currentNote = note;
        this.noteContent.innerHTML = note.content;
        this.noteContent.focus();
        
        // Update selected state in list
        const items = this.notesList.getElementsByClassName('note-item');
        for (let item of items) {
            item.classList.remove('selected');
            if (item.dataset.id === note.id.toString()) {
                item.classList.add('selected');
            }
        }
    }

    saveCurrentNote() {
        if (this.currentNote) {
            this.currentNote.content = this.noteContent.innerHTML;
            this.saveNotes();
            this.renderNotesList();
        }
    }

    deleteCurrentNote() {
        if (this.currentNote) {
            this.notes = this.notes.filter(note => note.id !== this.currentNote.id);
            this.saveNotes();
            this.renderNotesList();
            this.currentNote = null;
            this.noteContent.innerHTML = '';
        }
    }

    renderNotesList() {
        this.notesList.innerHTML = '';
        this.notes.forEach(note => {
            const noteElement = document.createElement('div');
            noteElement.className = 'note-item';
            noteElement.dataset.id = note.id;
            if (this.currentNote && this.currentNote.id === note.id) {
                noteElement.classList.add('selected');
            }

            noteElement.innerHTML = `
                <div class="note-title">${note.title}</div>
                <div class="note-date">${note.date}</div>
            `;

            noteElement.addEventListener('click', () => this.selectNote(note));
            this.notesList.appendChild(noteElement);
        });
    }

    saveNotes() {
        localStorage.setItem('notes', JSON.stringify(this.notes));
    }

    loadNotes() {
        const savedNotes = localStorage.getItem('notes');
        this.notes = savedNotes ? JSON.parse(savedNotes) : [];
        this.renderNotesList();
        
        if (this.notes.length > 0) {
            this.selectNote(this.notes[0]);
        } else {
            this.createNewNote();
        }
    }
}

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    window.notesApp = new NotesApp();
});
